/*******************************************************************************
* Copyright 2018-2022 Intel Corporation
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*******************************************************************************/

#include <assert.h>

#include "oneapi/dnnl/dnnl.h"

#include "c_types_map.hpp"
#include "engine.hpp"
#include "impl_list_item.hpp"
#include "primitive_cache.hpp"
#include "primitive_desc_iface.hpp"
#include "primitive_hashing.hpp"
#include "type_helpers.hpp"
#include "utils.hpp"

#include "sum_pd.hpp"

using namespace dnnl::impl;
using namespace dnnl::impl::utils;
using namespace dnnl::impl::status;

namespace dnnl {
namespace impl {

status_t sum_primitive_desc_create(primitive_desc_iface_t **sum_pd_iface,
        const memory_desc_t *dst_md, int n, const float *scales,
        const memory_desc_t *const *src_mds, const primitive_attr_t *attr,
        engine_t *engine) {

    bool args_ok = !any_null(sum_pd_iface, src_mds, scales) && n > 0;
    if (!args_ok) return invalid_arguments;

    if (attr == nullptr) attr = &default_attr();

    const int ndims = src_mds[0]->ndims;
    const dims_t &dims = src_mds[0]->dims;
    if (memory_desc_wrapper(src_mds[0]).has_runtime_dims_or_strides())
        return unimplemented;

    if (memory_desc_wrapper(src_mds[0]).format_any()) return invalid_arguments;
    for (int i = 1; i < n; ++i) {
        const memory_desc_t &src_md = *src_mds[i];
        if (src_md.ndims != ndims || memory_desc_wrapper(src_md).format_any())
            return invalid_arguments;
        if (memory_desc_wrapper(src_md).has_runtime_dims_or_strides())
            return unimplemented;
        for (int d = 0; d < ndims; ++d) {
            if (src_md.dims[d] != dims[d]) return invalid_arguments;
        }
    }

    memory_desc_t dummy_dst_md;
    if (dst_md) {
        if (dst_md->ndims != ndims) return invalid_arguments;
        if (memory_desc_wrapper(dst_md).has_runtime_dims_or_strides())
            return unimplemented;
        for (int d = 0; d < ndims; ++d) {
            if (dst_md->dims[d] != dims[d]) return invalid_arguments;
        }
    } else {
        dummy_dst_md = *src_mds[0];
        dummy_dst_md.format_kind = format_kind::any;
        dst_md = &dummy_dst_md;
    }

    auto desc = sum_desc_t(primitive_kind::sum, dst_md, n, scales, src_mds);
    primitive_hashing::key_t key(
            engine, reinterpret_cast<op_desc_t *>(&desc), attr, 0, {});
    auto pd = primitive_cache().get_pd(key);

    if (pd) {
        return safe_ptr_assign(
                *sum_pd_iface, new primitive_desc_iface_t(pd, engine));
    }

    for (auto s = engine->get_sum_implementation_list(); *s; ++s) {
        sum_pd_t *sum_pd = nullptr;
        if ((*s)(&sum_pd, engine, attr, dst_md, n, scales, src_mds)
                == success) {
            pd.reset(sum_pd);
            CHECK(safe_ptr_assign(
                    *sum_pd_iface, new primitive_desc_iface_t(pd, engine)));
            return status::success;
        }
    }
    return unimplemented;
}

} // namespace impl
} // namespace dnnl

status_t dnnl_sum_primitive_desc_create(primitive_desc_iface_t **sum_pd_iface,
        engine_t *engine, const memory_desc_t *dst_md, int n,
        const float *scales, const memory_desc_t *const *src_mds,
        const primitive_attr_t *attr) {
    return sum_primitive_desc_create(
            sum_pd_iface, dst_md, n, scales, src_mds, attr, engine);
}
