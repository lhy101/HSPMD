Graph Extension
###############

.. toctree::
   :maxdepth: 1

   graph_programming_model
   graph_supported_operations
   dev_guide_graph_fusion_patterns
   dev_guide_graph_dump
